# PBR
Project On Physically Based Rendering
These images were generated with 6 bounces and samples-per-pixel 16, 64, 128, 256, 512 and 1024 respectively. These results were with no stratified sampling.

![16](screenshots/16spp.png)
![64](screenshots/64spp.png)
![128](screenshots/128spp.png)
![256](screenshots/256spp.png)
![512](screenshots/512spp.png)
![1024](screenshots/1024spp.png)
